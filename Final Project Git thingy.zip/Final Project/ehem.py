from graphics import*
import Admin
def candInterface():
    win=GraphWin()
    win.setCoords(0,0,500,500)
    amount,mayina=Admin.candidates()
    if amount ==1:
        cand1=Image(Point(200,100),"CandBut.gif")
        cand1.draw(win)
    else:
        pass
