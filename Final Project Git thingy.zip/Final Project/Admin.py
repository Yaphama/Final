#This program is for the Election facilitator to input the 4 classes taking part in an election
#This program will trigger the other program to run thus run this program first
#Just Follow The simple instruction

#Input the classes taking part in the spaces
from Voter import*
import xlsxwriter
from sys import*
def introduction():
    print("ASHESI VOTER APPLICATION")
    print("Version 1.0.0")
    userHelp=open("Help.txt","r")
    print(userHelp.read())
    print("Please enter Y or N to agree below.\n")
    agreement=input("I Agree:").lower()
    if agreement=="y":
        pass
    else:
        exit()
    
def clxCreator(yrname):
    workbook = xlsxwriter.Workbook(str(yrname)+".xlsx")
    worksheet = workbook.add_worksheet()
    bold = workbook.add_format({'bold': True})
    worksheet.write('A1',yrname,bold)
    worksheet.write('A2', 'Id Numbers',bold)
    worksheet.write('B2', 'Member Voted For',bold)
    worksheet.set_column('A:B', 40)
def candidates():
    participants=[]
    num_Cand=int(input("Enter number of candidates:"))
    for i in range(num_Cand):
        candidate_name=input("enter name of candidate: ")
        participants.append(candidate_name)
    return num_Cand,participants
    
def yeargroups():
    classes=[]
    checker="n"
    while checker=="n":
        
        yrgroup=int(input("Classes taking part"))
        classes.append(yrgroup)
        checker=input("Done Y/N:").lower()
        
        if checker=='y':
            clxCreator(yrgroup)
            pass
        elif checker=='n':
            clxCreator(yrgroup)
        else:
            print("please enter the two letters y or n")
            clxCreator(yrgroup)
            yeargroups()

    return classes
def main():
    introduction()
    yeargroups()
    candidates()
    screen1()

main()
