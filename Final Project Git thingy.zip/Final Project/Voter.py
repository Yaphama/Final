#This Program is a voting application which will help a school like ashesi university to  conduct its election.

#interface 1
import xlsxwriter
from graphics import*
import Admin
def screens(name):
    cand=Image(Point(250,250),"CandBut.gif")
    cand.draw(win)
    candtext=Text(Point(250,250),name)
    
def interface():
  #cand1,cand2=Admin.candidates()
  win=GraphWin("Voter",350,400)
  win.setBackground("white")
  win.setCoords(0,0,400,500)
  logo=Image(Point(200,400),"log1.gif")
  logo.draw(win)
  #Welcome interface
  cond=True
  while cond==True:
    simpleText=Text(Point(50,250),"ID Number:")
    simpleText.draw(win)
    yrgroup=Text(Point(50,200),"Year Group:")
    yrgroup.draw(win)
    textBox=Entry(Point(200,250),20)
    textBox.draw(win)
    yrtxtbox=Entry(Point(200,200),20)
    yrtxtbox.draw(win)
    button=Image(Point(200,100),"button.gif")
    button.draw(win)
    m=win.getMouse()
    dx=m.getX()
    dy=m.getY()
    
    ###Phase two of voting process###
    if (dx>107 and dx<288) and (dy>61 and dy<138):
        textBox.undraw()
        yrtxtbox.undraw()
        button.undraw()
        simpleText.undraw()
        yrgroup.undraw()
        candInterface()
        cond=False
    else:
      cond=True
#Getting User Input from interface

    idinfo=textbox.getText()
#def candInterface():
#    amount,mayina=Admin.candidates()
#    n=0
#    if amount ==1:
#        screens(mayina[n])
#    elif amount>1:
#        next_but=Rectangle(Point(450,0),Point(500,25)).draw(win)
#        prev_but=Rectangle(Point(0,0),Point(50,25)).draw(win)
#        prev_but.setFill(colour_rgb(108,0,0))
#        next_but.setFill(colour_rgb(108,0,0))
#        next_text=Text(Point(475,12.5),"Next").draw(win)
#        prev_text=Text(Point(475,12.5),"Prev").draw(win)
#        click=true
#        count=0
#        while click==True:
#            screens(mayina[count])
#            click=m.getMouse()
#            dx=m.getX()
#            dy=m.getY()
#            if (dx<50 and dy<25):
#                if count<=0:
#                    click=True
#                else:
#                    count=count-1
#                    mayina[count]
#                    click=True
#            elif (dx>450 and dy<25):
#                if count==len(mayina)-1:
#                    click=True
#                    
#                elif count<len(mayina)-1:
#                    click=True
#                    count=count+1
#            elif (100<dx<400) and (100<dy<300):
#                click=False
#                interface()
#            else:
#                pass
#    else:
#        pass
#Voter Interface
#def writing(c1,c2,c3,c4): if c1==yrtxtbox.getText() or c2==yrtxtbox.getText or c3==yrtxtbox.getText() or c4==yrtxtbox.getText():
  #print()
  
